import { useEffect, useMemo, useState } from "react";
import { useSearchParams, Link } from "react-router-dom";
import { AlertTriangle, Download, FileText, GraduationCap, ListTodo, ClipboardCheck, Briefcase, LogOut, Activity, FlaskConical, RefreshCw, Printer, CheckSquare, Square, BarChart3, Clock, Users, CalendarClock, TrendingDown, Gauge, ShieldCheck } from "lucide-react";
import { api } from "../api";
import { useApi } from "../hooks";
import { Card, EmptyState, SectionTitle, Spinner, StatusBadge } from "../components/ui";
import { printDataTable } from "../lib/print";

const REPORT_TABS = [
  { id: "summary", label: "Dashboard summary", icon: FileText },
  { id: "daily_changes", label: "Daily changes (Registrar)", icon: RefreshCw },
  { id: "graduation_candidates", label: "Graduation candidates", icon: GraduationCap },
  { id: "missing_requirements", label: "Missing requirements", icon: ClipboardCheck },
  { id: "practicum_monitoring", label: "Practicum monitoring", icon: Briefcase },
  { id: "withdrawal_requests", label: "Withdrawal requests", icon: LogOut },
  { id: "loa_readmission", label: "LOA/readmission", icon: Activity },
  { id: "at_risk", label: "At-risk", icon: AlertTriangle },
  { id: "open_overdue_tasks", label: "Open/overdue tasks", icon: ListTodo },
  { id: "research_completion", label: "Research completion", icon: FlaskConical },
];

// Module 5 (Analytics and Decision Support) and Module 7 (Reporting and
// Dashboards). These are computed from recorded event history and are fetched
// separately so the operational reports above keep their load time.
const ANALYTICS_TABS = [
  { id: "queue_aging", label: "Queue aging & backlog", icon: Clock },
  { id: "stage_bottlenecks", label: "Stage bottlenecks", icon: BarChart3 },
  { id: "owner_workload", label: "Workload & turnaround", icon: Users },
  { id: "residency_watchlist", label: "Residency watchlist", icon: ShieldCheck },
  { id: "completion_attrition", label: "Completion & attrition", icon: TrendingDown },
  { id: "scheduling_cycle_time", label: "Scheduling cycle time", icon: CalendarClock },
  { id: "followup_closure", label: "Follow-up closure", icon: Gauge },
];

const ANALYTICS_IDS = new Set(ANALYTICS_TABS.map((tab) => tab.id));

export default function Reports() {
  const [searchParams, setSearchParams] = useSearchParams();
  const [active, setActive] = useState(searchParams.get("workflow_type") || "summary");
  const filters = useMemo(
    () => ({
      program_id: searchParams.get("program_id") || "",
      stage: searchParams.get("stage") || "",
      risk: searchParams.get("risk") || "",
      standing: searchParams.get("standing") || "",
      workflow_type: searchParams.get("workflow_type") || "",
    }),
    [searchParams]
  );
  const { data, loading, error } = useApi(
    () => api.reports(filters),
    [filters.program_id, filters.stage, filters.risk, filters.standing, filters.workflow_type]
  );

  // Analytics is loaded only once an analytics tab is opened, and reloaded when
  // the student filters change.
  const analyticsWanted = ANALYTICS_IDS.has(active);
  const [analytics, setAnalytics] = useState(null);
  const [analyticsLoading, setAnalyticsLoading] = useState(false);
  const [analyticsError, setAnalyticsError] = useState("");
  const analyticsKey = `${filters.program_id}|${filters.stage}|${filters.risk}|${filters.standing}`;

  useEffect(() => {
    if (!analyticsWanted) return undefined;
    let alive = true;
    setAnalyticsLoading(true);
    setAnalyticsError("");
    api
      .reportsAnalytics({
        program_id: filters.program_id,
        stage: filters.stage,
        risk: filters.risk,
        standing: filters.standing,
      })
      .then((res) => alive && setAnalytics(res))
      .catch((err) => alive && setAnalyticsError(err.message || "Could not load analytics."))
      .finally(() => alive && setAnalyticsLoading(false));
    return () => {
      alive = false;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [analyticsWanted, analyticsKey]);

  function updateFilter(key, value) {
    if (key === "workflow_type") setActive(value || "summary");
    const next = new URLSearchParams(searchParams);
    if (value) next.set(key, value);
    else next.delete(key);
    setSearchParams(next, { replace: true });
  }

  function chooseTab(id) {
    setActive(id);
    if (id === "summary") updateFilter("workflow_type", "");
    else updateFilter("workflow_type", id);
  }

  if (loading) return <Spinner label="Loading reports..." />;
  if (error) return <EmptyState icon={AlertTriangle} title="Could not load reports" hint={error} />;

  const activeTab =
    REPORT_TABS.find((tab) => tab.id === active) ||
    ANALYTICS_TABS.find((tab) => tab.id === active) ||
    REPORT_TABS[0];
  const rows = active === "summary" || analyticsWanted ? [] : data?.[active]?.rows || [];
  const analyticsReport = analyticsWanted ? analytics?.[active] : null;

  return (
    <div className="space-y-5 animate-fade-up">
      <div className="flex flex-wrap items-start justify-between gap-3">
        <div>
          <h1 className="font-display text-2xl font-semibold text-ink">Reports</h1>
          <p className="mt-1 text-sm text-slate-500">Filterable monitoring reports generated from student records, tasks, and workflow cases.</p>
        </div>
        <Link to="/" className="btn-ghost">Back to dashboard</Link>
      </div>

      <ReportFilters data={data} filters={filters} updateFilter={updateFilter} clear={() => setSearchParams({}, { replace: true })} />

      <div className="flex flex-wrap gap-2">
        {REPORT_TABS.map((tab) => {
          const Icon = tab.icon;
          const selected = activeTab.id === tab.id;
          const count = (tab.id === "summary" || tab.id === "daily_changes") ? null : data?.[tab.id]?.count || 0;
          return (
            <button
              key={tab.id}
              type="button"
              onClick={() => chooseTab(tab.id)}
              className={`inline-flex items-center gap-2 rounded-full px-3.5 py-2 text-sm font-semibold transition-colors ${
                selected ? "bg-brand-600 text-white" : "bg-white text-slate-600 ring-1 ring-slate-200 hover:bg-brand-50"
              }`}
            >
              <Icon className="h-4 w-4" /> {tab.label}{count !== null ? ` · ${count}` : ""}
            </button>
          );
        })}
      </div>

      <div>
        <p className="px-1 pb-2 text-[11px] font-bold uppercase tracking-wider text-slate-400">
          Analytics &amp; decision support
        </p>
        <div className="flex flex-wrap gap-2">
          {ANALYTICS_TABS.map((tab) => {
            const Icon = tab.icon;
            const selected = activeTab.id === tab.id;
            const count = analytics?.[tab.id]?.count;
            return (
              <button
                key={tab.id}
                type="button"
                onClick={() => chooseTab(tab.id)}
                className={`inline-flex items-center gap-2 rounded-full px-3.5 py-2 text-sm font-semibold transition-colors ${
                  selected ? "bg-brand-600 text-white" : "bg-white text-slate-600 ring-1 ring-slate-200 hover:bg-brand-50"
                }`}
              >
                <Icon className="h-4 w-4" /> {tab.label}
                {count !== undefined ? ` · ${count}` : ""}
              </button>
            );
          })}
        </div>
      </div>

      {active === "daily_changes" ? (
        <DailyChangesReport />
      ) : analyticsWanted ? (
        <AnalyticsPanel
          tab={activeTab}
          report={analyticsReport}
          kpis={analytics?.kpis}
          studentCount={analytics?.student_count}
          loading={analyticsLoading}
          error={analyticsError}
        />
      ) : (
        <Card className="p-5">
          <SectionTitle
            title={activeTab.label}
            icon={activeTab.icon}
            action={active !== "summary" && rows.length ? <button type="button" onClick={() => exportCsv(active, rows)} className="btn-ghost"><Download className="h-4 w-4" /> Export CSV</button> : null}
          />
          {active === "summary" ? <SummaryReport summary={data.summary} /> : <ReportTable type={active} rows={rows} />}
        </Card>
      )}
    </div>
  );
}

function ReportFilters({ data, filters, updateFilter, clear }) {
  const active = Object.values(filters).filter(Boolean).length;
  return (
    <Card className="p-4">
      <div className="grid grid-cols-1 gap-3 md:grid-cols-5">
        <Select label="Program" value={filters.program_id} onChange={(value) => updateFilter("program_id", value)}>
          <option value="">All programs</option>
          {(data?.programs || []).map((program) => <option key={program.id} value={program.id}>{program.code}</option>)}
        </Select>
        <Select label="Progress" value={filters.stage} onChange={(value) => updateFilter("stage", value)}>
          <option value="">All progress</option>
          {(data?.stages || []).map((stage) => <option key={stage} value={stage}>{stage}</option>)}
        </Select>
        <Select label="Risk" value={filters.risk} onChange={(value) => updateFilter("risk", value)}>
          <option value="">All risk</option>
          {["On Track", "At Risk of Delay", "Delayed", "Not Yet Assessed", "At Risk of Delay/Delayed"].map((risk) => <option key={risk} value={risk}>{risk}</option>)}
        </Select>
        <Select label="Standing" value={filters.standing} onChange={(value) => updateFilter("standing", value)}>
          <option value="">All standings</option>
          {["Active", "On Leave", "Withdrawn", "Completed"].map((standing) => <option key={standing} value={standing}>{standing}</option>)}
        </Select>
        <Select label="Workflow" value={filters.workflow_type} onChange={(value) => updateFilter("workflow_type", value)}>
          <option value="">All workflows</option>
          {REPORT_TABS.filter((tab) => tab.id !== "summary").map((tab) => <option key={tab.id} value={tab.id}>{tab.label}</option>)}
        </Select>
      </div>
      {active > 0 && <button type="button" onClick={clear} className="mt-3 text-xs font-semibold text-brand-700">Clear report filters</button>}
    </Card>
  );
}

function Select({ label, value, onChange, children }) {
  return (
    <label>
      <span className="field-label">{label}</span>
      <select value={value} onChange={(e) => onChange(e.target.value)} className="field-input cursor-pointer">{children}</select>
    </label>
  );
}

function SummaryReport({ summary }) {
  const cards = [
    ["Students monitored", summary.total_students],
    ["Needing attention", summary.at_risk],
    ["Open tasks", summary.pending_tasks],
    ["Overdue tasks", summary.overdue_tasks],
    ["Practicum records", summary.practicum_records],
    ["Withdrawal requests", summary.withdrawal_requests],
    ["Graduation candidates", summary.graduation_candidates],
    ["Confirmed defenses", summary.confirmed_schedules],
  ];
  return (
    <div className="grid grid-cols-2 gap-3 md:grid-cols-4">
      {cards.map(([label, value]) => (
        <div key={label} className="rounded-xl border border-slate-100 bg-slate-50/70 p-4">
          <p className="font-display text-2xl font-semibold text-ink">{value}</p>
          <p className="mt-1 text-xs font-semibold text-slate-500">{label}</p>
        </div>
      ))}
    </div>
  );
}

function AnalyticsPanel({ tab, report, kpis, studentCount, loading, error }) {
  if (loading) return <Spinner label={`Computing ${tab.label.toLowerCase()}...`} />;
  if (error) return <EmptyState icon={AlertTriangle} title="Could not load analytics" hint={error} />;
  const rows = report?.rows || [];
  const columns = report?.columns || [];
  return (
    <div className="space-y-5">
      {kpis?.length ? <KpiStrip kpis={kpis} /> : null}
      <Card className="p-5">
        <SectionTitle
          title={tab.label}
          icon={tab.icon}
          action={rows.length ? (
            <button type="button" onClick={() => exportAnalyticsCsv(tab.id, columns, rows)} className="btn-ghost">
              <Download className="h-4 w-4" /> Export CSV
            </button>
          ) : null}
        />
        <p className="-mt-1 mb-3 text-xs text-slate-500">
          Computed from recorded event history for {studentCount ?? 0} student(s) matching the filters.
        </p>
        {report?.totals ? <TotalsRow totals={report.totals} /> : null}
        {rows.length ? (
          <div className="overflow-x-auto rounded-xl border border-slate-100">
            <table className="w-full min-w-[760px] text-sm">
              <thead>
                <tr className="border-b border-slate-100 bg-slate-50 text-left text-xs font-bold uppercase tracking-wide text-slate-400">
                  {columns.map((col) => <th key={col.key} className="px-4 py-2.5">{col.label}</th>)}
                </tr>
              </thead>
              <tbody>
                {rows.map((row, index) => (
                  <tr key={index} className="border-b border-slate-50 align-top">
                    {columns.map((col) => (
                      <td key={col.key} className="px-4 py-2.5 text-slate-600">
                        {formatAnalyticsCell(row[col.key])}
                      </td>
                    ))}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        ) : (
          <EmptyState icon={FileText} title="Nothing to report" hint="No records match the current filters." />
        )}
      </Card>
    </div>
  );
}

function KpiStrip({ kpis }) {
  return (
    <Card className="p-5">
      <SectionTitle title="Module KPI measurements" icon={Gauge} />
      <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
        {kpis.map((kpi) => {
          const tone = kpi.met === null ? "text-slate-500" : kpi.met ? "text-emerald-600" : "text-amber-600";
          return (
            <div key={kpi.kpi} className="rounded-xl border border-slate-100 bg-slate-50/60 p-4">
              <p className="text-[11px] font-bold uppercase tracking-wide text-slate-400">{kpi.module}</p>
              <p className="mt-1 text-sm font-semibold text-ink">{kpi.kpi}</p>
              <p className={`mt-2 font-display text-2xl font-semibold ${tone}`}>
                {kpi.value}{kpi.unit}
              </p>
              <p className="text-xs text-slate-500">Target {kpi.target}</p>
              <p className="mt-1 text-xs text-slate-400">{kpi.basis}</p>
            </div>
          );
        })}
      </div>
    </Card>
  );
}

function TotalsRow({ totals }) {
  const entries = Object.entries(totals || {});
  if (!entries.length) return null;
  return (
    <div className="mb-3 flex flex-wrap gap-2">
      {entries.map(([key, value]) => (
        <span key={key} className="rounded-lg bg-brand-50 px-3 py-1.5 text-xs font-semibold text-brand-700">
          {key.replace(/_/g, " ")}: {formatAnalyticsCell(value)}
        </span>
      ))}
    </div>
  );
}

function formatAnalyticsCell(value) {
  if (value === null || value === undefined || value === "") return "—";
  if (typeof value === "number") return Number.isInteger(value) ? value : value.toFixed(1);
  return String(value);
}

function exportAnalyticsCsv(type, columns, rows) {
  const headers = columns.map((col) => col.label);
  const lines = [headers.map(csvCell).join(",")];
  rows.forEach((row) => {
    lines.push(columns.map((col) => csvCell(row[col.key])).join(","));
  });
  const blob = new Blob([lines.join("\n")], { type: "text/csv" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = `${type}.csv`;
  a.click();
  URL.revokeObjectURL(url);
}

function ReportTable({ type, rows }) {
  if (!rows.length) return <EmptyState icon={FileText} title="No rows match the filters" />;
  if (type === "graduation_candidates") return <GraduationTable rows={rows} />;
  if (type === "missing_requirements") return <MissingTable rows={rows} />;
  if (type === "practicum_monitoring") return <PracticumTable rows={rows} />;
  if (type === "withdrawal_requests") return <WithdrawalTable rows={rows} />;
  if (type === "loa_readmission") return <LoaTable rows={rows} />;
  if (type === "at_risk") return <RiskTable rows={rows} />;
  if (type === "open_overdue_tasks") return <TaskTable rows={rows} />;
  if (type === "research_completion") return <ResearchTable rows={rows} />;
  return null;
}

function BaseTable({ headers, rows, render }) {
  return (
    <div className="overflow-x-auto rounded-xl border border-slate-100">
      <table className="w-full min-w-[760px] text-sm">
        <thead>
          <tr className="border-b border-slate-100 bg-slate-50 text-left text-xs font-bold uppercase tracking-wide text-slate-400">
            {headers.map((header) => <th key={header} className="px-4 py-2.5">{header}</th>)}
          </tr>
        </thead>
        <tbody>{rows.map(render)}</tbody>
      </table>
    </div>
  );
}

function StudentCell({ student }) {
  return (
    <td className="px-4 py-2.5">
      <Link to={`/students/${student.id}`} className="font-semibold text-brand-700 hover:underline">{student.name}</Link>
      <p className="text-xs text-slate-400">{student.student_number} · {student.program_code}</p>
    </td>
  );
}

function GraduationTable({ rows }) {
  return <BaseTable headers={["Student", "Window", "Coursework", "Research", "Practicum", "Status"]} rows={rows} render={(row) => (
    <tr key={row.id} className="border-b border-slate-50">
      <StudentCell student={row.student} />
      <td className="px-4 py-2.5 text-slate-600">{row.review_window}</td>
      <td className="px-4 py-2.5"><StatusBadge value={row.coursework_status} dot={false} /></td>
      <td className="px-4 py-2.5"><StatusBadge value={row.research_status} dot={false} /></td>
      <td className="px-4 py-2.5"><StatusBadge value={row.practicum_status} dot={false} /></td>
      <td className="px-4 py-2.5"><StatusBadge value={row.endorsement_status} dot={false} /></td>
    </tr>
  )} />;
}

function MissingTable({ rows }) {
  return <BaseTable headers={["Student", "Coursework", "Research", "Practicum", "Next owner"]} rows={rows} render={(row) => (
    <tr key={row.student.id} className="border-b border-slate-50 align-top">
      <StudentCell student={row.student} />
      <td className="px-4 py-2.5 text-slate-600">{row.coursework.length ? row.coursework.join("; ") : "None"}</td>
      <td className="px-4 py-2.5 text-slate-600">{row.research.length ? row.research.join("; ") : "None"}</td>
      <td className="px-4 py-2.5 text-slate-600">{row.practicum || "None"}</td>
      <td className="px-4 py-2.5 text-slate-600">{row.next_owner}</td>
    </tr>
  )} />;
}

function PracticumTable({ rows }) {
  return <BaseTable headers={["Student", "Site", "Hours", "Documents", "Certificates", "Status"]} rows={rows} render={(row) => (
    <tr key={row.id} className="border-b border-slate-50">
      <StudentCell student={row.student} />
      <td className="px-4 py-2.5 text-slate-600">{row.practicum_site || "—"}</td>
      <td className="px-4 py-2.5 text-slate-600">{row.completed_hours}/{row.required_hours}</td>
      <td className="px-4 py-2.5"><StatusBadge value={row.document_status} dot={false} /></td>
      <td className="px-4 py-2.5 text-slate-600">{row.certificate_count}</td>
      <td className="px-4 py-2.5"><StatusBadge value={row.status} dot={false} /></td>
    </tr>
  )} />;
}

function WithdrawalTable({ rows }) {
  return <BaseTable headers={["Student", "Subject / semester", "Window", "Dean", "Registrar", "Academic record", "Status"]} rows={rows} render={(row) => (
    <tr key={row.id} className="border-b border-slate-50">
      <StudentCell student={row.student} />
      <td className="px-4 py-2.5 text-slate-600"><span className="font-semibold text-ink">{row.subject?.course_code || "—"}</span><span className="block text-xs">{row.effective_term || "—"}</span></td>
      <td className="px-4 py-2.5 text-xs text-slate-600">{row.withdrawal_window?.status || "—"}<span className="block">Deadline: {row.withdrawal_window?.deadline || "—"}</span></td>
      <td className="px-4 py-2.5"><StatusBadge value={row.dean_decision} dot={false} /></td>
      <td className="px-4 py-2.5"><StatusBadge value={row.registrar_status} dot={false} /></td>
      <td className="px-4 py-2.5 text-xs font-semibold text-emerald-700">{row.academic_record_effect || "No grade / no penalty"}</td>
      <td className="px-4 py-2.5"><StatusBadge value={row.status} dot={false} /></td>
    </tr>
  )} />;
}

function LoaTable({ rows }) {
  return <BaseTable headers={["Student", "Standing", "Stage", "Latest readmission"]} rows={rows} render={(row) => (
    <tr key={row.student.id} className="border-b border-slate-50">
      <StudentCell student={row.student} />
      <td className="px-4 py-2.5"><StatusBadge value={row.standing} dot={false} /></td>
      <td className="px-4 py-2.5 text-slate-600">{row.stage}</td>
      <td className="px-4 py-2.5 text-slate-600">{row.latest_readmission?.result || "No readmission action"}</td>
    </tr>
  )} />;
}

function RiskTable({ rows }) {
  return <BaseTable headers={["Student", "Risk", "Recommendation", "Owner"]} rows={rows} render={(row) => (
    <tr key={row.student.id} className="border-b border-slate-50">
      <StudentCell student={row.student} />
      <td className="px-4 py-2.5"><StatusBadge value={row.student.risk_level} dot={false} /></td>
      <td className="px-4 py-2.5 text-slate-600">{row.top_recommendation?.recommendation || "No recommendation"}</td>
      <td className="px-4 py-2.5 text-slate-600">{row.top_recommendation?.owner || "—"}</td>
    </tr>
  )} />;
}

function TaskTable({ rows }) {
  return <BaseTable headers={["Task", "Student", "Owner", "Due", "Status"]} rows={rows} render={(row) => (
    <tr key={row.id} className="border-b border-slate-50">
      <td className="px-4 py-2.5 font-semibold text-ink">{row.title}</td>
      <td className="px-4 py-2.5 text-slate-600">{row.student_name || "—"}</td>
      <td className="px-4 py-2.5 text-slate-600">{row.owner_role}</td>
      <td className="px-4 py-2.5 text-slate-600">{row.due_at}</td>
      <td className="px-4 py-2.5"><StatusBadge value={row.overdue ? "Overdue" : row.status} dot={false} /></td>
    </tr>
  )} />;
}

function ResearchTable({ rows }) {
  return <BaseTable headers={["Student", "Case", "Gate", "Status"]} rows={rows} render={(row) => (
    <tr key={row.case.id} className="border-b border-slate-50">
      <StudentCell student={row.student} />
      <td className="px-4 py-2.5 text-slate-600">{row.case.title}</td>
      <td className="px-4 py-2.5 text-slate-600">{row.case.current_gate_label}</td>
      <td className="px-4 py-2.5"><StatusBadge value={row.case.status} dot={false} /></td>
    </tr>
  )} />;
}

function todayISO() {
  const now = new Date();
  return new Date(now.getTime() - now.getTimezoneOffset() * 60000).toISOString().slice(0, 10);
}

function DailyChangesReport() {
  const [date, setDate] = useState(todayISO());
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [busyId, setBusyId] = useState(null);

  async function load(targetDate) {
    setLoading(true);
    setError("");
    try {
      const res = await api.dailyChanges(targetDate);
      setData(res);
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    load(date);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [date]);

  async function toggleReflected(item) {
    setBusyId(item.id);
    try {
      const next = !item.reflected_in_aims;
      await api.markChangeReflected(item.id, next);
      setData((current) => ({
        ...current,
        items: current.items.map((row) => (row.id === item.id ? { ...row, reflected_in_aims: next } : row)),
        summary: {
          ...current.summary,
          reflected: current.summary.reflected + (next ? 1 : -1),
          pending: current.summary.pending + (next ? -1 : 1),
        },
      }));
    } catch (err) {
      setError(err.message);
    } finally {
      setBusyId(null);
    }
  }

  const items = data?.items || [];
  const summary = data?.summary || { total: 0, reflected: 0, pending: 0 };

  function changeText(item) {
    if (item.previous_status && item.new_status && item.previous_status !== item.new_status) {
      return `${item.detail} (${item.previous_status} → ${item.new_status})`;
    }
    return item.detail;
  }

  function exportChangesCsv() {
    const headers = ["Time", "Change type", "Student", "Student No", "Program", "Change", "By", "Reflected in AIMS"];
    const lines = [headers.join(",")];
    items.forEach((item) => {
      lines.push([
        item.time, item.change_type, item.student_name, item.student_number,
        item.program_code, changeText(item), item.actor, item.reflected_in_aims ? "Yes" : "No",
      ].map(csvCell).join(","));
    });
    const blob = new Blob([lines.join("\n")], { type: "text/csv" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `registrar-changes-${date}.csv`;
    a.click();
    URL.revokeObjectURL(url);
  }

  function printChanges() {
    printDataTable({
      title: "Registrar update list — changes to apply in AIMS",
      subtitle: `Date: ${date}`,
      columns: ["Time", "Change type", "Student", "Student No", "Program", "Change", "By", "Reflected"],
      rows: items.map((item) => [
        item.time ? new Date(item.time).toLocaleTimeString() : "",
        item.change_type, item.student_name, item.student_number, item.program_code,
        changeText(item), item.actor, item.reflected_in_aims ? "Yes" : "No",
      ]),
    });
  }

  return (
    <Card className="p-5">
      <SectionTitle
        title="Daily changes for the Registrar"
        subtitle="Every change made in this system on the selected date. Use it to mirror updates into AIMS, then tick each one as reflected."
        icon={RefreshCw}
        action={
          <div className="flex flex-wrap items-center gap-2">
            <input type="date" value={date} onChange={(event) => setDate(event.target.value)} className="field-input max-w-44" aria-label="Change report date" />
            <button type="button" onClick={exportChangesCsv} disabled={!items.length} className="btn-ghost cursor-pointer"><Download className="h-4 w-4" /> CSV</button>
            <button type="button" onClick={printChanges} disabled={!items.length} className="btn-ghost cursor-pointer"><Printer className="h-4 w-4" /> Print</button>
          </div>
        }
      />

      <div className="mt-3 grid grid-cols-3 gap-3">
        <MiniStat label="Changes today" value={summary.total} />
        <MiniStat label="Reflected in AIMS" value={summary.reflected} tone="green" />
        <MiniStat label="Pending" value={summary.pending} tone="amber" />
      </div>

      {error && <div className="mt-3 rounded-xl border border-red-200 bg-red-50 px-4 py-2.5 text-sm font-medium text-red-700">{error}</div>}

      {loading ? (
        <div className="mt-4"><Spinner label="Loading changes…" /></div>
      ) : items.length === 0 ? (
        <div className="mt-4"><EmptyState icon={FileText} title="No changes on this date" hint="Pick another date, or make changes in Enrollment, Withdrawal, or the standing-change workflows." /></div>
      ) : (
        <div className="mt-4 overflow-x-auto rounded-xl border border-slate-100">
          <table className="w-full min-w-[820px] text-sm">
            <thead>
              <tr className="border-b border-slate-100 bg-slate-50 text-left text-xs font-bold uppercase tracking-wide text-slate-400">
                <th className="px-4 py-2.5">Time</th>
                <th className="px-4 py-2.5">Change type</th>
                <th className="px-4 py-2.5">Student</th>
                <th className="px-4 py-2.5">Change</th>
                <th className="px-4 py-2.5">By</th>
                <th className="px-4 py-2.5 text-right">Reflected in AIMS</th>
              </tr>
            </thead>
            <tbody>
              {items.map((item) => (
                <tr key={item.id} className="border-b border-slate-50 align-top">
                  <td className="px-4 py-2.5 text-slate-500">{item.time ? new Date(item.time).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }) : "—"}</td>
                  <td className="px-4 py-2.5"><StatusBadge value={item.change_type} dot={false} /></td>
                  <td className="px-4 py-2.5"><Link to={`/students/${item.student_id}`} className="font-semibold text-brand-700 hover:underline">{item.student_name}</Link><p className="text-xs text-slate-400">{item.student_number} · {item.program_code}</p></td>
                  <td className="px-4 py-2.5 text-slate-600">{changeText(item)}</td>
                  <td className="px-4 py-2.5 text-slate-500">{item.actor}</td>
                  <td className="px-4 py-2.5 text-right">
                    <button type="button" onClick={() => toggleReflected(item)} disabled={busyId === item.id} className={`inline-flex items-center gap-1.5 rounded-lg px-2.5 py-1.5 text-xs font-semibold cursor-pointer transition-colors ${item.reflected_in_aims ? "bg-green-100 text-green-700 hover:bg-green-200" : "bg-slate-100 text-slate-500 hover:bg-slate-200"}`}>
                      {item.reflected_in_aims ? <CheckSquare className="h-4 w-4" /> : <Square className="h-4 w-4" />}
                      {item.reflected_in_aims ? "Reflected" : "Mark reflected"}
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </Card>
  );
}

function MiniStat({ label, value, tone }) {
  const tones = { green: "text-green-700", amber: "text-amber-700" };
  return (
    <div className="rounded-xl border border-slate-100 bg-slate-50/70 p-4">
      <p className={`font-display text-2xl font-semibold ${tones[tone] || "text-ink"}`}>{value}</p>
      <p className="mt-1 text-xs font-semibold text-slate-500">{label}</p>
    </div>
  );
}

function exportCsv(type, rows) {
  const flattened = rows.map((row) => flattenRow(type, row));
  const headers = Object.keys(flattened[0] || {});
  const lines = [headers.join(",")];
  flattened.forEach((row) => {
    lines.push(headers.map((header) => csvCell(row[header])).join(","));
  });
  const blob = new Blob([lines.join("\n")], { type: "text/csv" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = `${type}.csv`;
  a.click();
  URL.revokeObjectURL(url);
}

function csvCell(value) {
  const text = Array.isArray(value) ? value.join("; ") : String(value ?? "");
  return `"${text.replace(/"/g, '""')}"`;
}

function flattenRow(type, row) {
  if (row.student) {
    return {
      student: row.student.name,
      student_number: row.student.student_number,
      program: row.student.program_code,
      status: row.status || row.endorsement_status || row.dean_decision || "",
      detail: row.review_window || row.practicum_site || row.effective_term || row.title || "",
    };
  }
  if (row.case) return { student: row.student.name, program: row.student.program_code, gate: row.case.current_gate_label, status: row.case.status };
  return {
    student: row.student?.name,
    program: row.student?.program_code,
    status: row.student?.risk_level || row.standing || row.status || "",
    detail: row.top_recommendation?.recommendation || row.next_owner || row.title || "",
  };
}
