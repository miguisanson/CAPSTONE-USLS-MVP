// PageHelp (UX-14, owner 2026-11-20): every process page has ONE "Help" button in its header. The rules that apply,
// the form and Operations Manual numbers, "How this works" and the recent activity all live in the side panel it opens,
// so the page itself starts with the work. Used by the process boards (ProcessBoardPage), the single workflow pages
// (WorkflowPage) and the Dean's Practicum board - the same parts on every page of that kind (IM24).
import { BookOpen, HelpCircle, History, X } from "lucide-react";
import { Button, Drawer } from "./ui/index.js";
import PolicyRules from "./PolicyRules";
import { formRefLine } from "../lib/formRefs.js";

export function HelpButton({ onClick }) {
  return (
    <Button variant="secondary" icon={HelpCircle} onClick={onClick} aria-haspopup="dialog">
      Help
    </Button>
  );
}

/**
 * @param title         the page's name ("Help: Leave of Absence")
 * @param forms         a key of lib/formRefs.js: the "Forms GS-F-07 · Operations Manual 4.6" line
 * @param rulesProcess  the process whose rules PolicyRules lists
 * @param onGuide       opens the "How this works" guide (the panel closes first)
 * @param onActivity    opens the recent activity (optional)
 * @param onClose       closes the panel
 */
export function PageHelpDrawer({ title, forms, rulesProcess, onGuide, onActivity, onClose }) {
  const formsLine = forms ? formRefLine(forms) : "";
  const open = (fn) => () => {
    onClose();
    fn();
  };
  return (
    <Drawer label={`Help: ${title}`} onClose={onClose}>
      <div className="flex items-center justify-between gap-3 border-b border-slate-200 px-5 py-4">
        <div className="min-w-0">
          <p className="eyebrow">Help</p>
          <h2 className="section-title break-words">{title}</h2>
        </div>
        <Button variant="icon" icon={X} aria-label="Close help" onClick={onClose} />
      </div>
      <div className="space-y-4 p-5">
        <div className="grid gap-2 sm:grid-cols-2">
          <Button variant="secondary" icon={BookOpen} onClick={open(onGuide)} className="justify-start">
            How this works
          </Button>
          {onActivity && (
            <Button variant="secondary" icon={History} onClick={open(onActivity)} className="justify-start">
              Recent activity
            </Button>
          )}
        </div>
        {rulesProcess && <PolicyRules process={rulesProcess} />}
        {formsLine && (
          <p data-slot="forms" className="meta">
            {formsLine}
          </p>
        )}
      </div>
    </Drawer>
  );
}
