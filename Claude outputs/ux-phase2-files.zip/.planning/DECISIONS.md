# Owner decisions — improvement mode

Settled with the owner through grill-me. Numbered `IM#` so they never collide with the
Decision Register `D1–D10` in `CHECKLIST_PHASE_PLAN.md`. A decision changes only through a
new grill-me with the owner; agents never re-decide these.

## 2026-10-17 — start of improvement mode (v5.2)

| # | Decision | What it means for the work |
|---|---|---|
| IM1 | **No deadline is fixed yet.** | Plan as if ~4 weeks remain. Every phase must leave the app demo-ready on its own, so stopping early never leaves a half-built state. |
| IM2 | **One database setup for the whole team: SQLite + a seed that gives identical data on every machine.** No shared online database. | One command resets any machine to exactly the same demo data. A fingerprint check proves two machines match. (Research: `research/DATABASE-FOR-TEAM.md` — `npm run seed` and a plain start produce different data today, e.g. 45 vs 71 panel assignments; that, not MySQL, is the main cause of mismatches.) |
| IM2a | **A seed-input fingerprint warns when the demo data is out of date.** | `build_demo_database` stamps a hash of the files the seed reads (`panel_demo_data.py`, `seed_curriculum_data.py`, `business_rules_catalog.py`, the Sample_Data sheets; CRLF = LF) into the SQLite `user_version`. A start that finds another or no stamp still starts, prints "Your demo data is out of date. Run npm run seed (this resets the demo data).", and the sign-in page shows the same notice (`/api/auth/config` `demo_data_stale`). No auto-reseed, no refusal; the schema-mismatch refusal stays. |
| IM3 | **MySQL support is removed.** | Delete the MySQL code paths (`normalize_database_url`/`is_mysql`/`ensure_mysql_database` in `app.py`), PyMySQL, and the MySQL sections of README/AGENTS. |
| IM4 | **The app is a demo/prototype only. It never holds real USLS data.** | The schema is built clean from the models. The startup `ALTER TABLE` patches and any data the app changes on a normal start are removed; resetting means rebuilding from the seed. This **replaces** the old "additive-only migrations" part of AGENTS.md Rule 4. The AIMS rule (official values are import-only, manual entries carry provenance) still stands. |
| IM5 | **Split `app.py` into modules** (models, services, one Flask blueprint per area, shared helpers), merging duplicated code on the way. | Behaviour stays the same. The existing unittest suite (~590 tests) is the safety net and runs after every move. Tests' `from app import …` keep working through a thin `app.py`. |
| IM6 | **One design system, not a redesign.** | Build on the existing tokens (`frontend/tailwind.config.js` USLS green, `index.css` `.card`/`.btn`). One scale for type, spacing, radius, shadows; shared components (page header, card, data table, status chip, button, form field, modal, stepper, decision panel); every page moves onto them. Same look, made consistent. |
| IM7 | **Automated browser walkthroughs with Playwright.** | Log in as each role on the seeded data, open every page, walk the main workflows; fail on console errors, failed requests, or overflow. Screenshots at the IM15 widths for the consistency review. |
| IM8 | **Order: foundations first.** | (1) Database + seed + archive dead files, (2) walkthrough tests, (3) `DEFENSE_REVISIONS.md` section J bugs, (4) backend split, (5) design system, (6) performance and the remaining cleanup. Stakeholder-blocked items in `DEFENSE_REVISIONS.md` stay waiting. |
| IM9 | **Work lands on branch `v5.2-migui_again`.** | One small commit per change, each with its test and (for visual changes) screenshots. The owner reviews and says when to merge into `v5.1-migui_clean`. Teammates keep using `v5.1-migui_clean` until then. |
| IM10 | **At most 3 implementer subagents at once.** | Each in its own worktree under `E:\Github_Projects\CAPSTONE-USLS-MVP-wt\<short>`, file sets must not overlap. One integrator (the main session) merges one packet at a time and re-runs the gate after each merge. Drop to 1 after any regression or red gate. Read-only research/audit agents are not capped. |
| IM11 | **No review cap: keep building.** | Agents do not stop at a number of unreviewed changes. Safety comes from IM9: every change is a separate, revertable commit with its own proof. The other stop conditions in `IMPROVE.md` still apply. |
| IM12 | **Proven-unused files and folders move to `archive/`**, not deleted. | "Proven" = grep shows nothing references it and the gate passes without it. `archive/README.md` lists each item, where it came from, and the evidence. Dead code *inside* a file (unused functions, routes, components) is deleted outright — git history keeps it. |
| IM13 | **Ideas from the research: cheap ones are built, the rest go to `IDEAS.md`.** | "Cheap" = frontend-only or one small endpoint, no new table, no change to a workflow rule or role permission, under ~150 changed lines. Anything else is listed in `IDEAS.md` with a recommendation, and waits for the owner's pick. |
| IM14 | **The seed spreadsheets are anonymized** (`Documents/Sample_Data/Monitoring_Sheets`, `Documents/Sample_Data/Faculty_Sheet`). | Safe to keep in git and to ship in a shared demo database snapshot. |
| IM15 | **Every page must work at 1366 px (laptop), 1920 px (desktop) and 390 px (phone).** | Walkthrough screenshots and the design-system review use these three widths. |
| IM16 | **Seed dates are relative to the day the seed runs.** | Deadlines and schedules always look current in a demo. The R-001 fingerprint compares dates as offsets from the seed day (and ignores salted password hashes), so two machines seeding on different days still match. |
| IM17 | **`outputs/` and the generated files under `scripts/docs/` move to `archive/` and stay tracked in git** (owner changed this on 2026-10-17: keep them just in case). | Only generated output (screenshots, built documents) moves; the scripts in `scripts/docs/` stay where they are, and any script that writes to a moved folder is updated to the new path. Everything in `archive/` is tracked. Closes I-028. |
| IM18 | **During unattended runs the agents never wait for the owner** (owner, 2026-10-17 night: "do not ask for any of my decisions … dont stop building"). | A question that would go to the owner is decided by the main session with its recommended option, logged below as `AD#` (agent decision, owner may veto in the morning), and work continues. Stop condition 5 in `IMPROVE.md` ("queue empty apart from owner items") does not stop the run while any agent-decidable work remains. |

## 2026-10-17 midday — grill-me on homes, reports, assistant (I-044..I-046)

| # | Decision | What it means for the work |
|---|---|---|
| IM19 | **One action-first home layout for every role** (idea X-06 approved). | Same structure on the student, faculty, dean, staff, coordinator and admin homes: "Needs your action" list first, then 3–4 key numbers (StatCard), then a short recent-activity list; the student home also shows the lifecycle Stepper. Duplicated blocks go. Charts leave the homes and move to Reports (IM20). Built on the Phase 5 components. |
| IM20 | **Reports = a few real exportable reports AND a short analytics section.** | Reports: (1) students at risk/delayed with the reason, (2) where each cohort is in the lifecycle by program, (3) overdue milestones and pending requests by office with waiting time, (4) defenses held/upcoming with verdicts, (5) graduation candidates — each with program/term/stage filters and Excel/PDF export. Analytics: 3–4 meaningful charts (cleaned-up versions of today's staff-home charts; no two-bar charts, readable axes). |
| IM21 | **Policy Assistant = Gemini, grounded and personal.** | Gemini (free Flash model) answers only from the uploaded USLS policy documents, always cites the document/section, and says the documents do not cover a question instead of guessing (fixes J13/I-013). It can also answer "what is my next step / what am I missing" from the signed-in user's own record. The keyword search stays as the offline fallback. |
| IM22 | **The owner adds the Gemini key; agents never open `.env`.** | A helper the owner runs (`npm run setup:env`) adds an empty `GOOGLE_API_KEY=` line if missing and removes the old MySQL `DATABASE_URL` line, printing only what it changed. Until a key exists, tests use a mocked Gemini response plus the fallback. |
| IM23 | **Priority for the rest of 2026-10-17:** role homes (IM19) first, then the Gemini assistant (IM21/IM22), section J backend bugs in parallel. | The Reports rebuild (IM20), the remaining page migrations, the app.py split and Phase 6 go to the next session via `/continue_CAPSTONE-USLS-MVP`. |
| IM24 | **Pages of the same kind behave the same** (owner, 2026-10-17 evening: "I want things to be consistent amongst pages if they are categorized like these" — LOA/readmission cards could be dragged, AWOL & Residency seemed not). | All process boards (Leave of Absence, Readmission, AWOL & Residency, Withdrawal, and the workflow boards in WorkflowPage such as Graduation/Practicum) offer the same features: board + table view, drag and "Move to…", the same card layout, filters, batch actions, history. A card that cannot move shows WHY on the card (a lock + "Waiting for: Student" / the owner, also in "Move to…"). A difference is allowed only when policy requires it, and then it is visible. The same rule applies to any other group of same-kind pages (e.g. the role homes, IM19). |

## Agent decisions (owner may veto)

| # | Date | Decision | Why |
|---|---|---|---|
| AD1 | 2026-10-17 | Accept the Phase 5 UI-SPEC's visible changes: info notices blue (were the same green as success); `Completed` standing green; `Draft` policy docs grey; Enter no longer confirms a destructive dialog; `Login.jsx` keeps its large title as the one size exception. | Standard semantic colours (Carbon/GOV.UK, research §3); info and success looked identical; safer destructive dialogs. Same look otherwise (IM6). |
| AD2 | 2026-10-17 | "Returned", "Returned for Revision/Clarification", "Returned to student" are **warning (amber)**, not danger (red) — overriding the draft spec. | Returned means someone must act, not that something failed; red is kept for denied/failed/overdue. |
| AD3 | 2026-10-17 | `frontend/src/lib/print.js` (an HTML string for the print window, not React) is allow-listed in `check-ui.allow.json` for `rawTable`/`rawH1` at P8 close-out instead of being rewritten. | It cannot use PageHeader/DataTable; printing works today. |
| AD4 | 2026-10-17 | Accept P1b's extra visible changes: `Submitted` chips blue (info) instead of amber, `Dropped` grey instead of violet, field hints one shade darker (slate-500), buttons 44 px tall on phones only. | All follow the approved spec (semantic tones, contrast, touch targets); desktop unchanged. |
| AD5 | 2026-10-17 | Stepper: a `Completed` student shows all 8 lifecycle steps complete plus a final complete "Completed" step (not a "stopped" chip); LOA/AWOL/Withdrawal show a trailing stopped chip and leave the path steps upcoming (the stage list does not record where they were). | A graduate marked "stopped" reads wrong; nothing is invented about earlier progress. |
| AD6 | 2026-10-17 | Monitoring record panel: Add/Edit of a subject row opens the editor in a block above the table instead of turning the row into a form; calendar defense-type colours (emerald/blue/violet/amber) stay as they are (they mean defense type, not status). | DataTable rows cannot hold a form; type colours are a legend, not the status map. |
| AD7 | 2026-10-17 | On every role home, "Needs your action" lists only what that user must do; items held by another office go in a smaller "Waiting on …" group under it (max 3 + View all). The open-tasks number counts only the user's own tasks. | A student cannot act on the coordinator's task; mixing them misleads (IM19). |

## 2026-10-22 — owner starts v5.3 (session opener)

Owner's words: "make a new branch call it v5.3-migui_test … use 4 helpers, make sure to find bug do bug fixes, use website skills look up online, research. do a complete improvement on this website … keep going without stopping … you may even use 1 time fable helper to conduct a full review. i wont make decisions, so i leave all decsiions upto you … this is a new branch anyway so go for it if you think tis better."

| # | Decision | What it means for the work |
|---|---|---|
| IM25 | **Work lands on branch `v5.3-migui_test`** (cut from `v5.2-migui_again` at c426b6f). | Replaces IM9's branch name for this run. Pushed to origin as work lands. `v5.1-migui_clean` and `v5.2-migui_again` are not touched. |
| IM26 | **Up to 4 implementer helpers at once** (supersedes IM10's 3). | Still one `app.py` editor at a time, non-overlapping file sets, one integrator, gate after every merge. Read-only review/research agents stay uncapped. One Fable full-app review is allowed. |
| IM27 | **All decisions are the agent's; bolder improvements are allowed on this branch.** | No QUESTION rows wait for the owner — the main session picks the recommended option and logs it as `AD#`. IM6 "not a redesign" is relaxed: a clearly better layout, flow or wording may replace the old one, as long as tests stay green, the demo flows keep working and the AIMS read-only rule (Rule 4) holds. |
| AD8 | 2026-10-22 | I-094 is not changed: the default demo student (Miguel Yu) is at Final Defense with all coursework done, so he has nothing to withdraw; the withdrawal demo uses the two withdrawal demo students (Elena Navarro, Joshua Lim). | The withdrawal window is the first two weeks of a semester (registrar calendar); inventing a current subject for a Final Defense student would contradict the record (I-061). |
| AD9 | 2026-10-22 | I-130: a case in Dean Review is locked for staff on every board ("Waiting for: Dean"); staff can no longer "Return to student" a withdrawal while the Dean holds it. | Same-kind boards behave the same (IM24): LOA, readmission and AWOL already lock at Dean Review; the Dean owns that decision and can return it. Server change in `standalone_process.py`, test first. |

## 2026-11-02 — owner starts v6.1 (grill-me before UAT)

Owner's words (summary): review Natalie's v6.0 changes (Google Calendar, .env), new branch `v6.1-migui`, run bug-fix and improvement loops non-stop until 80% of the weekly limit, Fable review at the end, do not make teammates' changes too drastic, multi-machine with at most 3 agents, UAT on miguisanson.dev from Wednesday 2026-11-04.

| # | Decision | What it means for the work |
|---|---|---|
| IM28 | **Work lands on `v6.1-migui`** (cut from `v6.0-natalie` at 80dd1aa). It is the one line for UAT; teammates pull it and branch off it. | `v6.0-natalie` and older branches are not touched. Pushed as work lands. |
| IM29 | **UAT is served from this PC** through a Cloudflare Tunnel at **`https://miguisanson.dev`** (bare domain). | Production serving (not the Flask dev server), HTTPS cookies, proxy headers, Google redirect URI on the new address. The PC must stay on and awake from Wednesday. |
| IM30 | **UAT uses the demo seed** (`npm run seed`), one login per role. No real student data online. | A reset is just a re-seed. Public exposure means demo-only shortcuts (reset buttons, known passwords) must be reviewed for a public site. |
| IM31 | **No e-mail sending for UAT** — notifications stay in the in-app bell. | Nothing new to build; Google Calendar events already reach connected faculty. |
| IM32 | **Dev kit: Ponytail + Caveman (lite level) in every project**, like Superpowers/GSD. | Installed user-level; dev-kit-setup lists and checks them. Replies to the owner stay plain English (lite). |
| IM33 | **At most 3 agents at once; the Mac is the preferred worker** for long test runs when it is online (Tailscale), else this PC. | Still one `app.py` editor at a time. Fable does one full review at the end. Run stops at 80% of the weekly limit. |
| AD10 | 2026-11-02 | Reports & Analytics follow `research/REPORTS-SPEC-2026-11-02.md` (I-141): one question per chart, 6-number summary strip with comparison, click-to-list everywhere, per-role tabs (Dean, Staff, Academic Coordinator, Research Coordinator), real stage clock. Before UAT: B1, B2, F1, B3/F2, B5/F4; the rest after. | Owner asked for reports that "make sense and are useful", based on references; the spec cites CGS, Few, EAB, PeopleSoft, Pitt. |
| AD11 | 2026-11-02 | I-159: when the Dean returns a practicum status report, the case goes back to the Academic Coordinator's review stage (status Completed, report-sent date cleared), not to "Additional Certificates Requested". The Dean's note is a student-visible message addressed to the Coordinator, so the Coordinator and the student both see it; the Coordinator then sends the report to the Dean again. The Dean button stays. | Ops Manual PRC-09: the Dean only reviews the report and marks it reviewed. The old landing state asked the student for certificates that were already verified and left the Coordinator no valid move. |
| AD12 | 2026-11-03 | I-158 / I-205: **Research Gate gets an overview list** like the other workflow pages: every active student with a research case, the stage, Ready / Blocked / Waiting / Done, who they wait on and why (filter by status and stage; a row opens the existing per-student record). Panel Matching and Defense Scheduling stay per-student: they depend on one chosen student's panel and slot, and the Research Gate list already shows who is ready for them (links go to the student). | Persona sweep 2 (Research Coordinator) could only open students one by one; the list answers "who is ready for panel matching / scheduling" without a new board. |
| IM34 | 2026-11-03 | Weekly percentage stops (70%/80%, `WEEKLY BUDGET`) removed everywhere — work runs until the real limit; 5-hour pause rules unchanged. | Owner 2026-11-03. Supersedes the weekly parts of the entries above. |
| IM35 | 2026-11-03 | Superseded 2026-11-03 by E:\ClaudeCode\CLAUDE.md 'Limits': at most 3 helpers at once (read-only research, audit and review agents count toward the 3), replacing the helper numbers in IM10 / IM26 / IM33; no new work at 90% of the 5-hour window (was 80%), save and `PAUSED for 5-hour limit` at 98%; Fable reviews allowed when worth it (replaces 'Fable once at the end'). | Owner 2026-11-03. One app.py editor at a time stays (merge safety). |
| IM36 | 2026-11-03 | Meeting prep: public site https://miguisanson.dev served from Docker (app + cloudflared) on this PC; the sign-in page keeps the demo-accounts panel visible (DEMO_SHOW_ACCOUNTS=1) for the stakeholder meeting; USLS forms are drafted without a draft mark, to be signed by the Graduate School; finished work is committed and pushed to v6.1-migui as it lands. | Owner answers 2026-11-03 (meeting 2026-11-04). Risk told: anyone with the URL can sign in as any demo role, Administrator included. |
| IM37 | 2026-11-03 | Owner away until ~10:00 2026-11-04 with full authority on choices: no questions, no owner testing; the agent tests everything itself. Safety: tag `uat-2026-11-04-base` marks the last known-good commit; overnight app-code changes land on v6.1-migui only after targeted tests + full gate, and the public Docker site is rebuilt only from a gated commit. | Owner 2026-11-03 21:3x: "I give you all jurisdiction on choices. Do not ask me of anything." |


## 2026-11-03 — owner-approved teaching timetable MVP

| # | Decision | What it means for the work |
|---|---|---|
| IM38 | The Academic Coordinator approves class schedules. | Explicit coordinator approval and publication; Dean offering approval remains unchanged. Admin superuser access does not substitute for the coordinator's scheduling decision. |
| IM39 | Faculty submit teaching availability by semester in a Schedule tab with a calendar view; teaching availability is distinct from defense availability. | Available/preferred/unavailable weekly periods, copy previous term and explicit confirmation; no student availability form. Current collection practice is unknown, so confirm how the portal replaces coordination during stakeholder validation. |
| IM40 | Approved paired days: Monday/Thursday, Tuesday/Friday, Wednesday/Saturday. | The implementation uses the proposed 07:30–21:00 / 90-minute / 15-minute grid as configurable defaults; the owner explicitly confirmed the paired days, not every timing detail. Single-day fallback remains an explicit coordinator opt-in. Confirmed enrollment conflicts are hard; curriculum forecasts remain warnings/soft ranking inputs. |
| IM41 | Room management remains free-text input; do not touch it. | No room inventory, room capacity or reservation/conflict engine is added. Existing defense venue behavior stays intact. |


## 2026-11-05 — final loop: stakeholder-agreed policy defaults (owner, v6.4.1-test)

Owner 2026-11-05: "all the questions you have needed the stakeholder said yes to them last meeting ... just go through
with it". Every open `question` row takes the policy-faithful default from `.planning/research/FABLE-REVIEW-2026-11-05.md`
section "Decisions for the question rows" (source cited per row there). Summary:

| # | Decision |
|---|---|
| IM42 | Build now: I-167 message only (no all-subjects withdrawal; file a LOA); I-170 one 20 % drop rule, no free-text exception; I-174 hard 14-day lead time (the "Skip date waits" demo switch also skips it); I-273 AWOL return checks the four returnee items; I-277 enrollment status derived from subject rows; I-278 window/fee judged from the first submission; I-284 one Form 4 at the proposal gate; I-285 Miguel Yu label fixed; I-297 Dean cannot approve readmission before clearance + interview are confirmed; I-299 residency purpose from the stage, checker runs by itself; I-302 two-week no-grant check re-run at Dean approval; I-306 subject tagged Withdrawn automatically on Dean approval; I-313 manuscript-received date derived and read-only; I-324 + F5-06 Graduation and Withdrawal get Sent to Registrar / Acknowledged like LOA; I-326 Failed/Deferred refuse a passing score; I-327 Turnitin similarity % recorded, above 15 refused; I-334 keep DEMO_SHOW_ACCOUNTS=1, fix UAT.md; I-348 restore `?student_id=` deep link; I-369 one sentence on sign-in, no share code. |
| IM43 | Build if time (M): I-248 three concept-paper titles at upload + pick list; I-252 verified practicum hours entered by the Academic Coordinator; I-304 Advise Slip on readmission approval; I-335 staff record the comprehensive exam result with provenance. |
| IM44 | Close, no build: I-053 (no batch for Withdrawal/Practicum), I-158 (Research Gate columns are the overview, AD12). Defer and name as known gaps in the Ops Manual: I-279 several subjects per withdrawal, I-293 Public Final Defense / Form 4.3 / Form 8, I-317 change of title, I-319 AC panel recommendation, I-326 per-member Form 7, I-346 student residency request page. |

| # | Decision (2026-11-05, Fable review 2) |
|---|---|
| IM45 | F6-01: a Withdrawal or Graduation case is closed at "Sent to Registrar" (Ops Manual WD-11: the Graduate School's duty ends when the request is sent); "Acknowledged" / "Registrar Received" stays an optional later step; supersedes IM42's "closed only at Acknowledged / Registrar Received". F6-02: staff cannot forward a readmission or a Return from AWOL until both returnee checks (Business Office clearance, interview) are ticked (Handbook p.45); the Dean's refusal text names what is missing and who confirms it. F6-03..F6-07 (P3) are fixed as the review says. |

## 2026-11-20 - UX audit implementation plan (owner)

Source: the UX audit and implementation plan doc (Claude, 2026-11-20). Claude implements phase by phase and stops at a
checkpoint after each phase for the owner's review.

| # | Decision |
|---|---|
| IM46 | Navigation: lighter touch. No Processes hub; the sidebar keeps its workflow lists, but the groups fold away (only the group holding the current page opens by default). Phase 5a. |
| IM47 | Names stay: Research Gate, Student Handoff and Standalone Processes keep their names. Phase 3 is limited to one status vocabulary and plainer descriptions. |
| IM48 | Drag stays as it is (no confirm-on-drag). |
| IM49 | Phases 0 and 1 run back to back, then stop for review. |
| IM50 | Owner 2026-11-20 (Phase 2): say a thing once. No subtitle or third line that repeats a heading; no status chip that repeats the due line; no header button to a page the sidebar already lists; no Refresh data button (the date sweeps run on the first sign-in each day). An unread row is a small dot, not a "New" badge; a row's link is an arrow. Applies to every page from now on. |
