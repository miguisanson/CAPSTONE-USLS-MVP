import { useState } from "react";
import { Link } from "react-router-dom";
import { ListTodo, AlertTriangle } from "lucide-react";
import { api } from "../api";
import { useApi } from "../hooks";
import { Card, Spinner, StatusBadge, EmptyState } from "../components/ui";
import { formatDate, relativeDays } from "../lib/format";

const OWNERS = ["GS Staff", "Academic Coordinator", "Research Coordinator", "Student", "Panel Chair", "Adviser"];

export default function WorkQueue() {
  const [owner, setOwner] = useState("");
  const { data, loading, error } = useApi(() => api.tasks(owner), [owner]);

  return (
    <div className="space-y-5 animate-fade-up">
      <div>
        <h1 className="font-display text-2xl font-semibold text-ink">Work Queue</h1>
        <p className="mt-1 text-sm text-slate-500">
          Pending and overdue tasks across the lifecycle — each one shows who owns the next action.
        </p>
      </div>

      <div className="flex flex-wrap gap-2">
        <FilterChip active={owner === ""} onClick={() => setOwner("")}>
          All owners
        </FilterChip>
        {OWNERS.map((o) => (
          <FilterChip key={o} active={owner === o} onClick={() => setOwner(o)}>
            {o}
          </FilterChip>
        ))}
      </div>

      <Card className="overflow-hidden">
        {loading ? (
          <Spinner label="Loading tasks…" />
        ) : error ? (
          <EmptyState icon={AlertTriangle} title="Could not load tasks" hint={error} />
        ) : data.items.length === 0 ? (
          <EmptyState icon={ListTodo} title="No open tasks" hint="This queue is clear. Nice." />
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full min-w-[680px] text-sm">
              <thead>
                <tr className="border-b border-slate-100 text-left text-xs font-bold uppercase tracking-wide text-slate-400">
                  <th className="px-5 py-3">Task</th>
                  <th className="px-3 py-3">Owner</th>
                  <th className="px-3 py-3">Student</th>
                  <th className="px-3 py-3">Due</th>
                  <th className="px-3 py-3">Status</th>
                </tr>
              </thead>
              <tbody>
                {data.items.map((task) => (
                  <tr key={task.id} className="border-b border-slate-50 hover:bg-slate-50/60">
                    <td className="px-5 py-3 font-semibold text-ink">{task.title}</td>
                    <td className="px-3 py-3 text-slate-600">{task.owner_role}</td>
                    <td className="px-3 py-3">
                      {task.student_id ? (
                        <Link to={`/students/${task.student_id}`} className="font-semibold text-brand-700 hover:underline">
                          {task.student_name}
                        </Link>
                      ) : (
                        <span className="text-slate-400">—</span>
                      )}
                    </td>
                    <td className="px-3 py-3 text-slate-500">
                      {formatDate(task.due_at)} <span className="text-slate-400">· {relativeDays(task.due_at)}</span>
                    </td>
                    <td className="px-3 py-3">
                      <StatusBadge value={task.overdue ? "Overdue" : task.status} dot={false} />
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </Card>
    </div>
  );
}

function FilterChip({ active, onClick, children }) {
  return (
    <button
      type="button"
      onClick={onClick}
      className={`rounded-full px-3.5 py-1.5 text-sm font-semibold transition-colors duration-200 cursor-pointer ${
        active ? "bg-brand-600 text-white" : "bg-white text-slate-600 ring-1 ring-slate-200 hover:bg-slate-50"
      }`}
    >
      {children}
    </button>
  );
}
